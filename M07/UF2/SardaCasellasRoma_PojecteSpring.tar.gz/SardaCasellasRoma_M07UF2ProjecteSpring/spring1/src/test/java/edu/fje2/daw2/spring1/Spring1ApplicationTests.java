package edu.fje2.daw2.spring1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
