package edu.fje2.daw2.spring1.model;

import org.springframework.data.annotation.Id;

/**
 * Entity class that represents an user.
 * 
 * @author Roma Sarda Casellas.
 */
public class Usuari {
    @Id
    public String id;

    public String codiUsuari;
    public String ciutat1;
    public String ciutat2;
    public String ciutat3;

    /**
     * Usuari constructor
     *
     * @param codiUsuari Username code from google auth.
     * @param ciutat1    First city entered from the user.
     * @param ciutat2    Second city entered from the user.
     * @param ciutat3    Third city entered from the user.
     */

    public Usuari(String codiUsuari, String ciutat1, String ciutat2, String ciutat3) {
        this.codiUsuari = codiUsuari;
        this.ciutat1 = ciutat1;
        this.ciutat2 = ciutat2;
        this.ciutat3 = ciutat3;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getcodiUsuari() {
        return codiUsuari;
    }

    public void setcodiUsuari(String codiUsuari) {
        this.codiUsuari = codiUsuari;
    }

    public String getCiutat1() {
        return ciutat1;
    }

    public void setCiutat1(String ciutat1) {
        this.ciutat1 = ciutat1;
    }

    public String getCiutat2() {
        return ciutat2;
    }

    public void setCiutat2(String ciutat2) {
        this.ciutat2 = ciutat2;
    }

    public String getCiutat3() {
        return ciutat3;
    }

    public void setCiutat3(String ciutat3) {
        this.ciutat3 = ciutat3;
    }

    @Override
    public String toString() {
        return "Usuari{" +
                "id='" + id + '\'' +
                ", codiUsuari='" + codiUsuari + '\'' +
                ", ciutat1='" + ciutat1 + '\'' +
                ", ciutat2='" + ciutat2 + '\'' +
                ", ciutat3=" + ciutat3 +
                '}';
    }
}