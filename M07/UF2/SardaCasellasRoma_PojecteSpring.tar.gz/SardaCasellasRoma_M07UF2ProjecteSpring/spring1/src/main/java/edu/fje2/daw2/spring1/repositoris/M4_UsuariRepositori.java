package edu.fje2.daw2.spring1.repositoris;

import edu.fje2.daw2.spring1.model.Usuari;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

/**
 * Interface for data persistence with Spring Data and MongoDB.
 * 
 * @author Roma Sarda Casellas.
 */

public interface M4_UsuariRepositori extends MongoRepository<Usuari, String> {
    Usuari findByCodiUsuari(String codiUsuari);

    List<Usuari> findByCiutat1(String ciutat1);

    List<Usuari> findByCiutat2(String ciutat2);

    List<Usuari> findByCiutat3(String ciutat3);
}