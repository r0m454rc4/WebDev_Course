package edu.fje.daw2.repositoris;

import edu.fje.daw2.model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientRepositori extends CrudRepository<Client, Long> {

}