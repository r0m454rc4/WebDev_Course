use mysql;
grant create on bdcli.* to 'adcli'@'localhost';
grant select,insert,delete, update on bdcli.* to 'adcli'@'localhost';

