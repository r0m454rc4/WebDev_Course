import { Alumne } from "./exercici3-Alumne";
import { SegonAlumne } from "./exercici3-SegonAlumne";

window.onload = () => {
  Alumne();
  SegonAlumne();
};
