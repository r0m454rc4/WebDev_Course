export let SegonAlumne = () => {};
