var server = require("./codi_examen");
// var server = require("./M05_servidorMilloratGET");

server.iniciar();
