var server = require("./calcularMitjana");
// var server = require("./M05_servidorMilloratGET");

server.iniciar();
