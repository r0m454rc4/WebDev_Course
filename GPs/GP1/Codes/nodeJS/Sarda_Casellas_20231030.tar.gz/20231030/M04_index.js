var server = require("./operacionsParametres-QueryString");
// var server = require("./M04_servidorMillorat");

server.iniciar();
