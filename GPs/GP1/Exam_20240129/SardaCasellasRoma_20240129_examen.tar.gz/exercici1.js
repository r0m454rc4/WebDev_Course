window.onload = () => {
  var canvas = document.getElementById("exercici");
  var context = canvas.getContext("2d");

  let dibuixaRectangle = (context, x, y, angleInicial) => {
    if (canvas.getContext) {
      context.save();
      context.beginPath();
      context.moveTo(0, 0);
      context.lineTo(100, 0);
      context.lineTo(100, 100);
      context.lineTo(0, 100);
      context.rotate(angleInicial);
      context.closePath();

      context.fill();
    }
  };

  let poligon = (context, x, y, radi, costats, angleInicial, antiHorari) => {
    if (canvas.getContext) {
      if (costats < 3) return;
      var a = (Math.PI * 2) / costats;
      a = antiHorari ? -a : a;
      context.save();
      context.translate(x, y);
      context.rotate(angleInicial);
      context.moveTo(radi, 0);

      for (let i = 0; i < costats; i++) {
        context.lineTo(radi * Math.cos(a * i), radi * Math.sin(a * i));
      }

      context.closePath;
      context.restore;
    }
  };

  let x = Math.floor(Math.random() * 200);
  let y = Math.floor(Math.random() * 200);
  let angleInicial = Math.floor(Math.random() * 365);
  dibuixaRectangle(context, x, y, angleInicial);
};
