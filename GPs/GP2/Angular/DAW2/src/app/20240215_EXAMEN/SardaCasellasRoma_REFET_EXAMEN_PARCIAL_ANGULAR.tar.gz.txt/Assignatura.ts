// Class that represents a subject.

// This class now implements the atributs from IPersona interface.
export class Assignatura {
  nota: string;

  constructor(nota: string) {
    this.nota = nota;
  }
}
