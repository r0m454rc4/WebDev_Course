import { Component } from '@angular/core';

@Component({
  selector: 'aplicacio',
  templateUrl: './Exercici3-CrearAlumne.html',
  styles: [
    `
      table {
        border-collapse: collapse;
      }
    `,
  ],
})
export class Exercici3CrearComponent {}
