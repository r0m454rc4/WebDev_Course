// Interface that represents a team.

interface IEquip {
  esport: string;
  categoria: string;
  nomEquip: string;
}

export { IEquip };
