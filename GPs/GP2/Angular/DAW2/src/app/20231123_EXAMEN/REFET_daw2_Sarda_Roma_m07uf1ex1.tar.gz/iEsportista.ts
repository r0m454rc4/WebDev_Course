// Interface that represents a sporstman.

interface IEsportista {
  dniEsportista: string;
  nomEsportista: string;
  posicioEsportista: string;
}

export { IEsportista };
